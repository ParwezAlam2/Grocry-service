<?php
$path = $_SERVER['DOCUMENT_ROOT'];
$path .= "/grocery/";

require_once($path . 'connect.php');

// Initialize the session
session_start();

if (!(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true && $_SESSION['role'] == 'admin')) {
	echo "Unauthorized Access";
	return;
}

$ReadSql = "SELECT * FROM `contact_us`";
$res = mysqli_query($connection, $ReadSql);

?>
	
<?php require($path . 'templates/header1.php') ?>
	<div class="container-fluid my-4">
		<div class="row my-2">
			<h2>Grocery Service - Customer's Message</h2>	
		</div>
		<table class="table "> 
		<thead> 
			<tr> 
				<th>Message No.</th> 
				<th>Name</th> 
				<th>Email</th> 
				<th>Phone</th>
				<th>Subject</th>
				<th>Message</th>
			</tr> 
		</thead> 
		<tbody> 
		<?php 
		while($r = mysqli_fetch_assoc($res)){
		?>
			<tr> 
				<th scope="row"><?php echo $r['id']; ?></th> 
				<td><?php echo $r['name']; ?></td> 
				<td><?php echo $r['email']; ?></td> 
				<td><?php echo $r['phone']; ?></td> 
				<td><?php echo $r['subject']; ?></td> 
				<td><?php echo $r['message']; ?></td> 
			</tr> 
		<?php } ?>
		</tbody> 
		</table>
	</div>

<?php require($path . 'templates/footer.php') ?>