
</div>
<!-- footer -->
<footer class="footer-container row justify-content-center mt-4 py-3">
	<div class="text-white"> Created by <span> SIP </span> | All Rights Reserved | Grocery Service</div>
</footer>
<script src="<?php echo $server; ?>js/script.js"></script>
</body>
</html>