#...codegenes.net...#

1. unzip the downloaded folder in your localhost root directory (e.g: htdocs in xamp, www in wamp) 
2. adjust your database setting in connect.php
3. import the groceryl.sql file in your database
4. go to  http://localhost/grocery/   


existing users:
role - admin
	name - admin@gmail.com
	password - password

role - customer
	email- codegenes@gmail.com
	password- codegenes


Use product images from the img/products folder